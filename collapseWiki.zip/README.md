# Collapse for Wikipedia

An add-on to collapse by section in Wikipedia. Useful for filtering out information that you don't need.

